<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BLOCKED</title>
    <style>
                body{
                background-image:url(img/block.jpg);
                background-position:center;
                background-size:cover;
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
                
            }
            *{
                font-family:  sans-serif;
                box-sizing: border-box;
            }
            form{
                border: 2px solid #ccc;
                padding: 92px;
                background: #423b3b59;
                border-radius: 20px;
            }
            </style>
</head>
<body>
    <form action="#">
    <center><h1 style="color:white;">You are BLOCKED :(</h1></center>
    </form>
</body>
</html>